package com.company;

import java.util.ArrayList;
import java.util.List;

public class Tier{
    public String name;
    public List<Tier> children = new ArrayList<>();
}

