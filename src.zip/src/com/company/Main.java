package com.company;

import java.util.List;

public class Main {
    static Tier one = new Tier();

    public static void main(String[] args) {
        Recursion recursionHelper = new Recursion();
        List<Tier> childrenOfSix = recursionHelper.addList(4);
        Tier six = new Tier();
        six.name = "six";
        six.children = childrenOfSix;

        List<Tier> childrenOfFive = recursionHelper.addList( 4);
        Tier five = new Tier();
        five.name = "five";
        childrenOfFive.add(six);
        five.children = childrenOfFive;

        List<Tier> childrenOfFour = recursionHelper.addList( 4);
        Tier four = new Tier();
        four.name = "four";
        childrenOfFour.add(five);
        four.children = childrenOfFour;

        List<Tier> childrenOfThree = recursionHelper.addList( 4);
        Tier three = new Tier();
        three.name = "three";
        childrenOfThree.add(four);
        three.children = childrenOfThree;

        List<Tier> childrenOfTwo = recursionHelper.addList( 4);
        Tier two = new Tier();
        two.name = "two";
        childrenOfTwo.add(three);
        two.children = childrenOfTwo;

        List<Tier> childrenOfOne = recursionHelper.addList( 4);
        childrenOfOne.add(two);
        one.name = "one";
        one.children = childrenOfOne;

        Recursion qwe = new Recursion();
        String allHtml = " <ul class='nav '>";
        allHtml += qwe.run_recursion(one);
        allHtml+="</ul>";

        System.out.printf(allHtml);
    }
}
